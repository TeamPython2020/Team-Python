#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Nov 29 11:57:01 2020

@author: karlybland
"""

import pandas as pd


df = pd.read_csv("covidcasesbystate_modified.csv")
df2 = pd.read_csv("mental_processed.csv")


df2.head(0)
df2.columns = ['Phase', 'Indicator', 'Group', 'State', 'Subgroup', 'Time_Period', 'date',
               'Value', 'Low_CI', 'High_CI', 'Confidence_Interval', 'Quartile_range']

df.columns = ["unnamed", 'date', 'state', 'cases', 'deaths']

dates2 = list(set(df2.date))  


df["date"] = pd.to_datetime(df["date"])



updated_df = df['date'].astype('datetime64[ns]')
dates1 = list(set(df.date))
apr23 = (df['date'] >= '2020-04-23') & (df['date'] < '2020-05-07')
may7 = (df['date'] >= '2020-05-07') & (df['date'] < '2020-05-14')
may15 = (df['date'] >= '2020-05-14') & (df['date'] < '2020-05-21')
may21 = (df['date'] >= '2020-05-21') & (df['date'] < '2020-05-28')
may28 =(df['date'] >= '2020-05-28') & (df['date'] < '2020-06-04')
jun4 = (df['date'] >= '2020-06-04') & (df['date'] < '2020-06-11')
jun11 = (df['date'] >= '2020-06-11') & (df['date'] < '2020-06-18')
jun18 = (df['date'] >= '2020-06-18') & (df['date'] < '2020-06-25')
jun25 = (df['date'] >= '2020-06-25') & (df['date'] < '2020-07-02')
jul2 =(df['date'] >= '2020-07-02') & (df['date'] < '2020-07-09')
jul9 = (df['date'] >= '2020-07-09') & (df['date'] < '2020-07-16')
jul16 = (df['date'] >= '2020-07-16') & (df['date'] < '2020-07-23')
aug19 = (df['date'] >= '2020-08-19') & (df['date'] < '2020-09-02')
sep2 = (df['date'] >= '2020-09-02') & (df['date'] < '2020-09-16')
sep16 = (df['date'] >= '2020-09-16') & (df['date'] < '2020-09-30')
sep30 = (df['date'] >= '2020-09-30') & (df['date'] < '2020-10-14')
oct14 =(df['date'] >= '2020-10-14') & (df['date'] < '2020-10-26')

df.loc[apr23, "date"]= "Apr 23 - May 5"
df.loc[may7, "date"]= 'May 7 - May 12'
df.loc[may15, "date"]= 'May 14 - May 19'
df.loc[may21, "date"]= 'May 21 - May 26'
df.loc[may28, "date"]= 'May 28 - June 2'
df.loc[jun4, "date"]= 'June 4 - June 9'
df.loc[jun11, "date"]= 'June 11 - June 16'
df.loc[jun18, "date"]= 'June 18 - June 23'
df.loc[jun25, "date"]= 'June 25 - June 30'
df.loc[jul2, "date"]= 'July 2 - July 7'
df.loc[jul9, "date"]= 'July 9 - July 14'
df.loc[jul16, "date"]= 'July 16 - July 21'
df.loc[aug19, "date"]= 'Aug 19 - Aug 31'
df.loc[sep2, "date"]= 'Sep 2 - Sep 14'
df.loc[sep16, "date"]= 'Sep 16 - Sep 28'
df.loc[sep30, "date"]= 'Sep 30 - Oct 12'
df.loc[oct14, "date"]= 'Oct 14 - Oct 26'


casesByState_datesModified = df[(df.date == "Apr 23 - May 5") | (df.date == 'May 7 - May 12') |
        (df.date == 'May 14 - May 19') | (df.date == 'May 21 - May 26') |
        (df.date == 'May 28 - June 2') | (df.date == 'June 4 - June 9') |
        (df.date == 'June 11 - June 16') | (df.date == 'June 18 - June 23') |
        (df.date == 'June 25 - June 30') | (df.date == 'July 2 - July 7') |
        (df.date == 'July 9 - July 14') | (df.date == 'July 16 - July 21') |
        (df.date == 'Aug 19 - Aug 31') | (df.date == 'Sep 2 - Sep 14') |
        (df.date == 'Sep 16 - Sep 28') | (df.date == 'Sep 30 - Oct 12') |
        (df.date == 'Oct 14 - Oct 26') ] 

#casesByState_datesModified.to_csv(r'/Users/karlybland/Desktop/CIS 9650/casesByState_datesModified.csv', index = False)



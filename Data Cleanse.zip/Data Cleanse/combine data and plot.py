import pandas as pd
import matplotlib.pyplot as plt


# Custom aggregation function to be used with groupby. This function runs through the rows of the dataframe it is given
# and finds the first date to go past the minimum percentage and maximum percentage. It then calculates the number of days
# in between and returns a new dataframe with that metric and the other metrics that don't change by date (population,
# land size, etc.)
def days_to_max(df, min_pct=.01, max_pct=.5):
    # sor the values first, so that the first time we reach above min and max, we can be sure this is the first time it
    # happened.
    tmp_df = df.sort_values('cases percentage')
    first_row = True
    state = ''
    density = 0
    pop = 0
    land_area = 0
    min_date = None
    max_date = None
    days = 0

    # loop through rows and look for min and max percentage. Note the dates when this first happens.
    for index, row in tmp_df.iterrows():
        # collect statewide data on the first row. This should be the same for every row, so no need to do it again.
        if first_row:
            first_row = False
            state = row['State']
            density = row['Density']
            pop = row['Pop']
            land_area = row['LandArea']
        if row['cases percentage'] > min_pct and min_date is None:
            min_date = row['date']
        if row['cases percentage'] > max_pct and max_date is None:
            max_date = row['date']
    if min_date is not None and max_date is not None:
        days = max_date - min_date
    return pd.DataFrame({'State': [state], 'Density': [density], 'Pop': [pop], 'LandArea': [land_area], 'Days to Max': [days.days]})


# Load some initial datasets and create a 'working' dataset by combining them and grouping by State.
def create_working_dataset():
    covid_df = pd.read_csv('.\\covidcasesbystate_modified.csv')
    covid_df['date'] = pd.to_datetime(covid_df['date'])
    state_name_df = pd.read_csv('.\\State Name Translations.csv')
    state_pop_df = pd.read_csv('.\\population2.csv')

    # Merge DataFrames. Drop any non states (Puerto Rico, Guam, etc.) and extraneous rows.
    tmp_df = pd.merge(covid_df, state_name_df, left_on='state', right_on='State')
    tmp_df = tmp_df.drop(['state', 'State', 'Abbrev'], axis=1)
    tmp_df = pd.merge(tmp_df, state_pop_df, left_on='Code', right_on='State')
    tmp_df = tmp_df.drop(['Code'], axis=1)

    # Create a new column that calculates the amount of cases as a percentage of population.
    tmp_df['cases percentage'] = (tmp_df['cases'] / tmp_df['Pop']) * 100

    # Group by state. Use custom aggregation function to calculate number of days between a min and max case percentage (default is .01% for min and .5% for max.
    tmp_df = tmp_df.groupby('State', group_keys=False).apply(days_to_max)
    tmp_df = tmp_df.reset_index(drop=True) # fix index
    return tmp_df


# create our 'working' data set.
working_df = create_working_dataset()

# combine with election data.
election_df = pd.read_csv('.\\clean_elections.csv')
election_df = election_df[election_df['party'] == 'democrat']
working_df = pd.merge(working_df, election_df, left_on='State', right_on='state_po')

# plot some initial results.
density_plot_df = working_df[working_df['State'] != 'DC'] # DC density is an outlier
density_plot_df.plot.scatter(x='Days to Max', y='Density')
plt.show()

working_df.plot.scatter(x='Days to Max', y='win_percentage')
plt.show()

working_df.to_csv('Cleaned Election and Covid Data.csv')
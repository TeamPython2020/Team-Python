import pandas as pd

# Read in data
df = pd.read_csv('elections.csv')

# Drop any rows with missing data
df = df.dropna()

# Remove columns we are not interested in
df = df.drop(['state', 'county', 'FIPS', 'office', 'candidate', 'version'], axis=1)

# Aggregate votes broken down by year, state, and party. Continue to include those dimensions as columns.
grouped_df = df.groupby(['year', 'state_po', 'party']).sum()
grouped_df = grouped_df.reset_index()

# Create new column to represent percentage of vote that each party won.
grouped_df['win_percentage'] = grouped_df['candidatevotes'] / grouped_df['totalvotes']

# Drop the year column (no longer needed). Aggregate on state and party and take the average of the win percentages over years.
# Include state and party as columns.
grouped_df = grouped_df.drop(['year'], axis=1)
final_df = grouped_df.groupby(['state_po', 'party']).mean()
final_df = final_df.reset_index()

# Output date to new csv file.
final_df.to_csv('clean_elections.csv')
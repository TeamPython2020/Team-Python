# -*- coding: utf-8 -*-
"""
Created on Mon Nov 23 12:48:41 2020

@author: claud
"""

import pandas as pd

#dataframe
df = pd.read_csv("covidcasesbystate.csv",
                 header = 0,
                 names = ['date','state','flips','cases','deaths'])

df2 = df.drop(df.columns[[2]], axis=1) #dont need flips in dataset
df2.to_csv('covidcasesbystate_modified.csv')
print(df2)


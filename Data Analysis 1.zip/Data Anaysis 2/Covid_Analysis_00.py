# Covid Data Analysis
import pandas as pd
df = pd.read_csv("casesByState_datesModified.csv") 

print("Step 1: Reading file...")
print(len(df.index), "records were read from file.\n")
df.head()


df1 = df.groupby("state")['cases'].sum()
print(df1)


import os
import math
import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.metrics import accuracy_score, roc_curve, auc, recall_score, precision_score, f1_score
import matplotlib.pylab as plt
from dmba import plotDecisionTree, classificationSummary, regressionSummary
from dmba import liftChart, gainsChart

df_join = pd.read_csv("joineddataalldates.csv")
df_join.head()



df2 = df_join.drop(columns=['Time Period Label', 'state', 'Indicator','deaths'])
df2.head()



predictors = ['Value', 'Low CI', 'High CI', 'Density', 'Pop', 'LandArea', 'democrat', 'green', 'republican']
outcome = 'cases'
X = pd.get_dummies(df_join[predictors], drop_first=True)
y = df_join[outcome]

train_X, valid_X, train_y, valid_y = train_test_split(X, y, test_size=0.4, random_state=1)

DecisionTree = DecisionTreeClassifier(max_depth = 4)
DecisionTree.fit(train_X, train_y)

plotDecisionTree(DecisionTree, feature_names=train_X.columns)


df1_join = df_join.groupby("state")['cases'].sum()
print(df1_join)

df2_join = df_join.groupby('state', as_index=False).sum()
df2_join.head()



from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier

predictors = ['Value', 'Low CI', 'High CI', 'Density', 'Pop', 'LandArea', 'democrat', 'green', 'republican']
outcome = 'cases'
X = pd.get_dummies(df2_join[predictors], drop_first=True)
y = df2_join[outcome]

train_X, valid_X, train_y, valid_y = train_test_split(X, y, test_size=0.4, random_state=1)

DecisionTree = DecisionTreeClassifier(max_depth = 4)
DecisionTree.fit(train_X, train_y)

plotDecisionTree(DecisionTree, feature_names=train_X.columns)



import os
import math
import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.metrics import accuracy_score, roc_curve, auc, recall_score, precision_score, f1_score
import matplotlib.pylab as plt
from dmba import plotDecisionTree, classificationSummary, regressionSummary
from dmba import liftChart, gainsChart


#df_join = pd.read_csv("joineddataalldates.csv")
df2_join = pd.read_csv("Cleaned Election and Covid Data.csv", index_col=0, na_values=['(NA)']).fillna(0)
#df2_join = df_join.groupby('state', as_index=False).sum()
df2_join.head()
#df2_join['cases', 'deaths', 'Value', 'Low CI', 'High CI', 'Density', 'Pop', 'LandArea', 'democrat', 'green', 'republican'].astype(float)



import numpy as np
from pandas.plotting import scatter_matrix, parallel_coordinates
import seaborn as sns
import matplotlib.pylab as plt
import matplotlib.pyplot as plt

sns.lmplot(x="Density", y="Days to Max", data=df2_join)
plt.xlim(-10, 250)
plt.ylim(-10, 250)
plt.title('Days to Max Vs Density for All States')
plt.xlabel('Density')
plt.ylabel('Days to Max')
plt.tight_layout()
plt.show()


sns.lmplot(x="Days to Max", y="Density", data=df2_join)
plt.xlim(-10, 300)
plt.ylim(-10,1500)
plt.title('Density Vs Days to Max for All States')
plt.xlabel('Days to Max')
plt.ylabel('Density')
plt.tight_layout()
plt.show()


import numpy as np
from pandas.plotting import scatter_matrix, parallel_coordinates
import seaborn as sns
import matplotlib.pylab as plt
import matplotlib.pyplot as plt

df_join = pd.read_csv("joineddataalldates.csv", index_col=0, na_values=['(NA)']).fillna(0)
df3_join = df_join.groupby('state', as_index=False).sum()
df3_join.head()

sns.lmplot(x="cases", y="Pop", data=df3_join)
#plt.xlim(-10000, 310000)
plt.title('Population Vs Cases for All States')
plt.xlabel('Cases')
plt.ylabel('Population')
plt.tight_layout()
plt.show()


sns.lmplot(x="cases", y="deaths", data=df3_join)
plt.title('Deaths Vs Cases for All States')
plt.xlabel('Cases')
plt.ylabel('Deaths')
plt.tight_layout()
plt.show()


# Seaborn visualization library
import seaborn as sns# Create the default pairplot
sns.pairplot(df_join)

